Powerline fonts
===============

This repository contains pre-patched and adjusted fonts for usage with the 
new Powerline plugin.

**IMPORTANT:** If you're running Linux you may not have to use a patched 
font! See the `Powerline font installation instructions 
<http://lokaltog.github.com/powerline/overview.html#font-installation>`_ for 
details.
